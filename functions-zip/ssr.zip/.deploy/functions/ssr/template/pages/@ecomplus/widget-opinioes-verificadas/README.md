# Widget Opiniões Verificadas

Storefront plugin for [Opiniões Verificadas](https://www.opinioes-verificadas.com.br/) to buyer review and store reliability
